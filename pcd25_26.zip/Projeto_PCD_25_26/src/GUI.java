import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class GUI {
	private JFrame Janela;
		private JLabel perguntas;
		private JLabel tempo;
		private javax.swing.Timer cronometro;
		private JLabel placar;
		private JButton[] opcao = new JButton[4];
		
		private int temporestante;
		private int duracao = 20;
		
		private GameState game;
		private String Jogador = "tu";
		private final java.util.Map<String,String> Player_Team =
		        java.util.Map.of("tu", "TEAM-A");
	
	public GUI() {
		Janela = new JFrame ("Is Kahoot da patricia e do João");
		Janela.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //quando fechamos a aplicação fecha mesmo
		Janela.setResizable(false); //deixa o tamanho fixo
		Janela.setLayout(new java.awt.BorderLayout());  // para oganizar em north south center
		javax.swing.JPanel top = new javax.swing.JPanel(new java.awt.GridLayout(2,2));
		javax.swing.JPanel center = new javax.swing.JPanel(new java.awt.GridLayout(2,2,8,8));
		
		perguntas = new javax.swing.JLabel("question");
		perguntas.setHorizontalAlignment(SwingConstants.CENTER);
		tempo = new javax.swing.JLabel("time = " + duracao);
		tempo.setHorizontalAlignment(SwingConstants.CENTER);
		placar = new javax.swing.JLabel("Placar: waiting");
		placar.setHorizontalAlignment(SwingConstants.CENTER);
		cronometro = new javax.swing.Timer(1000, e -> contagem()); 
		for(int i = 0; i < 4; i++) {
			opcao [i] = new javax.swing.JButton("Opção " + (i+1));
			center.add(opcao[i]);
		}
		for(int i = 0; i < 4;i++) {
			int o = i;
			opcao[i].addActionListener(e -> Selecionar(o));
		}
		
		top.add(perguntas);
		top.add(tempo);
		Janela.add(top, java.awt.BorderLayout.NORTH);
		Janela.add(center, java.awt.BorderLayout.CENTER);
		Janela.add(placar, java.awt.BorderLayout.SOUTH);
		
	}
	
	 //questões//
	
	public  void questao ( String pergunta, java.util.List<String> opcoes) {
		perguntas.setText(pergunta);
			for( int i = 0; i < opcao.length && i < opcoes.size(); i++ ) {
				opcao[i].setText(opcoes.get(i));
				opcao[i].setEnabled(true);
			}
			
			start(duracao);
	}
	
	private void ativarOpcoes (boolean ativar) {
		for( javax.swing.JButton b: opcao) {
			b.setEnabled(ativar);
		}
	}
	
	private void Selecionar (int i) {
		placar.setText("Opção: " + (i +1));
		ativarOpcoes(false); //Para não se alterar a resposta/cliques repetidos
		stop();
		game.resposta(Jogador, i);
		nextQ();
	}
	
	//Cronometro
	
	private void start(int duracao) {
		temporestante= duracao;
		tempo.setText("Tempo restante: " + temporestante + "segs");
		cronometro.start();
	}
	
	private void stop () {
		if(cronometro.isRunning()) {
			cronometro.stop();
		}
	}
	
	private void contagem() {
		temporestante --;
		tempo.setText("Tempo restante: " + temporestante + "segs");
			if(temporestante <= 0) {
				cronometro.stop();
				ativarOpcoes(false);
				placar.setText("Acabou o tempo");
				nextQ();
			}
	}
	
	//GameState
	
	public void SetUp(Quizz quizz) {
		this.game = new GameState(quizz);
	}
	public void questaoAtual () {
		Questao q = game.atual();
		questao (q.questao,q.opcoes);
		abrirRonda();
	}
	
	public void abrirRonda() {
		game.Ronda();
	}
	
	
	private void nextQ() {
		placar.setText("Placar:" + game.CalcularScore(Player_Team));
			if(game.hasNextQuestion()) {
				game.NextQuestion();
				Questao q = game.atual();
				questao(q.questao, q.opcoes);
				game.Ronda();
			}else {
				ativarOpcoes(false);
				stop();
				placar.setText("Placar Final:" + game.Scores());
			}
	}
	

	public void open () {	
		Janela.pack(); //compacta
		Janela.setSize(Janela.getWidth()*5, Janela.getHeight() *2);
		Janela.setLocationRelativeTo(null); //centra
		Janela.setVisible(true); //mostra
	}
	
	
}
