import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

public class GUI {
	private JFrame Janela;
		private JLabel perguntas;
		private JLabel cronometro;
		private JLabel placar;
		private JButton[] opcao = new JButton[4];
		
	
	public GUI() {
		Janela = new JFrame ("Is Kahoot da patricia e do João");
		Janela.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); //quando fechamos a aplicação fecha mesmo
		Janela.setResizable(false); //deixa o tamanho fixo
		Janela.setLayout(new java.awt.BorderLayout());  // para oganizar em north south center
		javax.swing.JPanel top = new javax.swing.JPanel(new java.awt.GridLayout(4,4));
		javax.swing.JPanel center = new javax.swing.JPanel(new java.awt.GridLayout(2,2,8,8));
		
		perguntas = new javax.swing.JLabel("question");
		perguntas.setHorizontalAlignment(SwingConstants.CENTER);
		cronometro = new javax.swing.JLabel("time = 60s");
		cronometro.setHorizontalAlignment(SwingConstants.CENTER);
		placar = new javax.swing.JLabel("Placar: waiting");
		placar.setHorizontalAlignment(SwingConstants.CENTER);
		for(int i = 0; i < 4; i++) {
			opcao [i] = new javax.swing.JButton("Opção " + (i+1));
			center.add(opcao[i]);
		}
		for(int i = 0; i < 4;i++) {
			int o = i;
			opcao[i].addActionListener(e -> Selecionar(o));
		}
		
		top.add(perguntas);
		top.add(cronometro);
		Janela.add(top, java.awt.BorderLayout.NORTH);
		Janela.add(center, java.awt.BorderLayout.CENTER);
		Janela.add(placar, java.awt.BorderLayout.SOUTH);
		
	}
	
	
	public  void questao ( String pergunta, java.util.List<String> opcoes) {
		perguntas.setText(pergunta);
			for( int i = 0; i < opcao.length && i < opcoes.size(); i++ ) {
				opcao[i].setText(opcoes.get(i));
				opcao[i].setEnabled(true);
			}
			placar.setText("Escolha a opção");
		
	}
	
	private void ativarOpcoes (boolean ativar) {
		for( javax.swing.JButton b: opcao) {
			b.setEnabled(ativar);
		}
	}
	
	private void Selecionar (int i) {
		placar.setText("Opção: " + (i +1));
		ativarOpcoes(false); //Para não se alterar a resposta/cliques repetidos
	}
	
	
	

	public void open () {	
		Janela.pack(); //compacta
		Janela.setSize(Janela.getWidth()*5, Janela.getHeight() *2);
		Janela.setLocationRelativeTo(null); //centra
		Janela.setVisible(true); //mostra
	}
	
	
}
