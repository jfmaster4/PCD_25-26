
public class main {
	public static void main (String [] args) {
		javax.swing.SwingUtilities.invokeLater(() -> {
			GUI game = new GUI();
			game.open();
			game.questao ("O que é uma thread?",java.util.Arrays.asList("Processo", "Aplicação", "Programa", "Processo Ligeiro"));
		});
	}
}
