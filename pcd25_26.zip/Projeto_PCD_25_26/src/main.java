
public class main {
	public static void main (String [] args) {
		javax.swing.SwingUtilities.invokeLater(() -> {
		 try {
			 Quizz quiz = LoaderJson.LoadJson("questions.json");
			 
			GUI game = new GUI();
			game.SetUp(quiz);
			game.open();
			game.questaoAtual();
		 } catch (Exception e) {
			 e.printStackTrace();
			 javax.swing.JOptionPane.showMessageDialog(null, "Erro ao carregar quizz");
		 }
		});
	}
}
