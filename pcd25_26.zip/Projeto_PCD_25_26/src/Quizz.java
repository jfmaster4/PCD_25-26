
public class Quizz {
	@com.google.gson.annotations.SerializedName("name")
	public String nome;
	@com.google.gson.annotations.SerializedName("questions")
	public java.util.List<Questao> questoes;

}

