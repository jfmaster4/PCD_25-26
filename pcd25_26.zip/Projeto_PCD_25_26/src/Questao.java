
public class Questao {
	@com.google.gson.annotations.SerializedName("question")
	public String questao;
	@com.google.gson.annotations.SerializedName("points")
	public int pontos = 0;
	@com.google.gson.annotations.SerializedName("correct")
	public int correta;
	@com.google.gson.annotations.SerializedName("options")
	public java.util.List<String> opcoes;
}

