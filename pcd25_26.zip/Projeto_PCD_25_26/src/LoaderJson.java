import com.google.gson.*;
import com.google.gson.annotations.SerializedName;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;


public class LoaderJson {

	 
	public static Quizz LoadJson(String path) throws Exception {
		
		String json = Files.readString(Paths.get(path));
		
		JsonObject root = JsonParser.parseString(json).getAsJsonObject();
		JsonArray quizzes = root.getAsJsonArray("quizzes");
		
		Quizz quiz = new Gson().fromJson(quizzes.get(0),Quizz.class);
		
			if(quiz.nome == null) 
				quiz.nome = "Quizz mistério";
			if(quiz.questoes == null)
				throw new IllegalArgumentException ("sem Opcoes");
			for(Questao q : quiz.questoes) {
			if (q.opcoes == null || q.opcoes.size() < 2 ) 
				throw new IllegalArgumentException ("Faltam opções na pergunta: ");
			if(q.correta < 0 || q.correta >= q.opcoes.size())
				throw new IllegalArgumentException ("Opcao correta inválida; ");
			if(q.pontos < 0 ) 
				q.pontos = 0;
		}
		
			return quiz;
	}
	
	
}
