import java.util.*;
public class GameState {
private final Quizz quizz;
private int indiceQ = 0;
private boolean novaRonda = false;

private final Map<String, Integer> respostas = new HashMap<>();
private final Map<String, Integer> pontuacoes = new HashMap<>();


public GameState (Quizz quizz) {
	this.quizz = quizz;
}

public Questao atual() {
	return quizz.questoes.get(indiceQ);
}

public void Ronda() {
	respostas.clear();
	novaRonda = true;
}

public void resposta ( String idJogador, int idOpcao) {
	if(!novaRonda) {
		return;
	}
	respostas.putIfAbsent(idJogador,idOpcao);
}




public Map<String,Integer> CalcularScore (Map<String,String> Player_Team) {
	
	if(respostas.isEmpty()) 
		return java.util.Collections.unmodifiableMap(pontuacoes);
Questao q = atual();
	for(var e : respostas.entrySet()) {
		String player = e.getKey();
		int opcao = e.getValue();
		String team = Player_Team.getOrDefault(player, "Team A");
		int pontos;
		if(opcao == q.correta) {
			pontos = q.pontos;
		}else {
			pontos = 0;
		}if ( pontuacoes.containsKey(team)) {
			int pontuacao = pontuacoes.get(team);
			pontuacoes.put(team, pontuacao + pontos);
			
		}else {
			pontuacoes.put(team, pontos);
		}
		}
	respostas.clear();
	novaRonda = false;
	return java.util.Collections.unmodifiableMap(pontuacoes);
}

public boolean hasNextQuestion() {
	if(indiceQ + 1 < quizz.questoes.size()) {
		return true;
	}else {
		return false;
	}
}

public void NextQuestion() {
	if(hasNextQuestion() == true) {
		indiceQ ++;
	}
	}

public Map <String,Integer> Scores() {
	return java.util.Collections.unmodifiableMap(pontuacoes);
}

}
