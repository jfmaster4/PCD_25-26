import java.util.*;

public class GameState {
    private final Map<String, Team> teams = new LinkedHashMap<>();
    private final Map<String, Player> players = new LinkedHashMap<>();
    private final List<Question> questions;
    private int currentIndex = -1;
    private final Map<String, Integer> answersThisRound = new LinkedHashMap<>();

    public GameState(List<Question> questions) {
        this.questions = new ArrayList<>(questions);
    }

    public boolean addTeam(String teamCode) {
        if (teams.containsKey(teamCode)) return false;
        teams.put(teamCode, new Team(teamCode));
        return true;
    }
    public boolean addPlayer(String username, String teamCode) {
        if (players.containsKey(username))
        	return false;
        Team t = teams.get(teamCode);
        if (t == null)
        	return false;
        Player p = new Player(username, teamCode);
        players.put(username, p);
        t.getPlayers().put(username, p);
        return true;
    }

    public boolean hasNextQuestion() {
    	return currentIndex + 1 < questions.size();
    }
    
    public Question startNextRound() {
        if (!hasNextQuestion())
        	return null;
        currentIndex++;
        answersThisRound.clear();
        return questions.get(currentIndex);
    }
    
    public Question getCurrentQuestion() {
        if (currentIndex < 0 || currentIndex >= questions.size())
        	return null;
        return questions.get(currentIndex);
    }

    public boolean submitAnswer(String playerId, int optionIndex) {
        if (getCurrentQuestion() == null)
        	return false;
        if (!players.containsKey(playerId))
        	return false;
        if (answersThisRound.containsKey(playerId))
        	return false;
        
        answersThisRound.put(playerId, optionIndex);
        return true;
    }
    
    public boolean isRoundComplete() {
    	return answersThisRound.size() == players.size();
    }

}
