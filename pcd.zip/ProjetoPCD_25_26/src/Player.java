public class Player {
    private final String id;
    private final String team;

    public Player(String id, String team) {
        this.id = id;
        this.team = team;
    }
    public String getId() {
    	return id;
    }
    
    public String getTeam() {
    	return team;
    }
}
