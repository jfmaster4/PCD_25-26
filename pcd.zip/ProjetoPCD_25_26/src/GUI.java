// GUI.java (trechos principais)
import java.util.List;
import java.util.function.IntConsumer;
import javax.swing.*;
import java.awt.*;

public class GUI {
    private final JFrame janela;
    private final JLabel perguntas;
    private final JLabel cronometro;
    private final JLabel placar;
    private final JLabel instrucoes;
    private final JButton[] opcao = new JButton[4];
    private IntConsumer onSelect; // callback para lógica externa
    private Timer timer;
    private int remaining;
    private Runnable onTimeout;
    
    private String sala = "-";
    private String equipa = "-";
    private String username = "-";

    public GUI() {
        janela = new JFrame("IsKahoot — Patrícia & João");
        janela.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        janela.setResizable(false);
        janela.setLayout(new BorderLayout());

        JPanel top = new JPanel(new GridLayout(3,1,4,4));   // 3 linhas: instruçao "escolha opção", pergunta e cronómetro
        JPanel center = new JPanel(new GridLayout(2,2,8,8)); // 4 botões 2x2

        perguntas = new JLabel("question", SwingConstants.CENTER);
        cronometro = new JLabel("time = 60s", SwingConstants.CENTER);
        placar = new JLabel("Placar: waiting", SwingConstants.CENTER);
        instrucoes = new JLabel("ESCOLHA A OPÇÃO", SwingConstants.CENTER);


        for (int i = 0; i < 4; i++) {
            final int idx = i;
            opcao[i] = new JButton("Opção " + (i + 1));
            opcao[i].addActionListener(e -> selecionar(idx));
            center.add(opcao[i]);
        }

        top.add(perguntas);
        top.add(cronometro);
        top.add(instrucoes);
        janela.add(top, BorderLayout.NORTH);
        janela.add(center, BorderLayout.CENTER);
        janela.add(placar, BorderLayout.SOUTH);
    }
    
    public JFrame getJanela() {
    	return janela;
    }
    
    public void setInstrucao(String txt) {
    	instrucoes.setText(txt);
    }

    private void refreshSession() {
        placar.setText(String.format("Sala: %s  |  Equipa: %s  |  Jogador: %s",
                sala, equipa, username));
    }

    public void setSessionInfo(String sala, String equipa, String username) {
        this.sala = sala;
        this.equipa = equipa;
        this.username = username;
        refreshSession();
    }

    public void questao(String pergunta, List<String> opcoes) {
        perguntas.setText(pergunta);
        for (int i = 0; i < opcao.length; i++) {
            if (i < opcoes.size()) { opcao[i].setText(opcoes.get(i)); opcao[i].setEnabled(true); opcao[i].setVisible(true); }
            else opcao[i].setVisible(false);
        }
        setInstrucao("ESCOLHA A OPÇÃO");
        refreshSession();                
    }

    public void atualizarCronometro(int segundos) {
        cronometro.setText("time = " + segundos + "s");
    }

    public void atualizarPlacar(String texto) {
        placar.setText(texto);
    }

    public void bloquearOpcoes(boolean bloquear) {
        for (JButton b : opcao) b.setEnabled(!bloquear);
    }

    private void selecionar(int i) {
        atualizarPlacar("Opção: " + (i + 1));
        bloquearOpcoes(true);
        if (onSelect != null) onSelect.accept(i);
    }

    public void open() {
        janela.pack();
        janela.setSize(janela.getWidth() * 5, janela.getHeight() * 2);
        janela.setLocationRelativeTo(null);
        janela.setVisible(true);
    }
    
    public void startCronometro(int segundos, Runnable onTimeout) {
        if (timer != null) timer.stop();
        this.remaining = segundos;
        this.onTimeout = onTimeout;
        atualizarCronometro(remaining);
        timer = new Timer(1000, e -> {
            remaining--;
            atualizarCronometro(remaining);
            if (remaining <= 0) {
                ((Timer)e.getSource()).stop();
                bloquearOpcoes(true);
                atualizarPlacar("Tempo esgotado!");
                if (this.onTimeout != null) this.onTimeout.run();
            }
        });
        timer.setInitialDelay(1000);
        timer.start();
    }

    public void reset() {
        if (timer != null) timer.stop();
        atualizarPlacar("Escolha a opção");
        bloquearOpcoes(false);
        for (JButton b : opcao) b.setVisible(true);
        atualizarCronometro(0);
    }
    
    public static String[] pedirCredenciais(java.awt.Window parent) {
        JTextField sala   = new JTextField();
        JTextField equipa = new JTextField();
        JTextField user   = new JTextField();

        JPanel panel = new JPanel(new java.awt.GridLayout(0,1,4,4));
        panel.add(new JLabel("Sala (código do jogo):"));
        panel.add(sala);
        panel.add(new JLabel("Equipa:"));
        panel.add(equipa);
        panel.add(new JLabel("Username:"));
        panel.add(user);

        int res = JOptionPane.showConfirmDialog(
            parent, panel, "Entrar no jogo",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
        );

        if (res == JOptionPane.CANCEL_OPTION || res == JOptionPane.CLOSED_OPTION) {
            if (parent != null)
            	parent.dispose();
            System.exit(0);
        }

        if (res == JOptionPane.OK_OPTION) {
            String s = sala.getText().trim();
            String e = equipa.getText().trim();
            String u = user.getText().trim();

            if (s.isEmpty() || e.isEmpty() || u.isEmpty()) {
                JOptionPane.showMessageDialog(parent, "Preenche todos os campos.");
                return pedirCredenciais(parent);
            }

            return new String[]{ s, e, u };
        }

        return null; // fallback
    }


}
