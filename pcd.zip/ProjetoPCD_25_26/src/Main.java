public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            GUI game = new GUI();
            game.open();

            // Pedir Sala / Equipa / Username
            String[] cred = GUI.pedirCredenciais(game.getJanela()); // ou null
            if (cred == null) return; // user cancelou
            String sala = cred[0], equipa = cred[1], username = cred[2];

            game.setSessionInfo(sala, equipa, username);

            // Pergunta de demonstração
            game.reset();
            game.questao("O que é uma thread?",
                java.util.Arrays.asList("Processo","Aplicação","Programa","Processo Ligeiro"));

            game.startCronometro(20, () -> game.atualizarPlacar("Tempo esgotado!"));
        });
    }
}
