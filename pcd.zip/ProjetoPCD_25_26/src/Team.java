import java.util.LinkedHashMap;
import java.util.Map;

public class Team {
    private final String code;
    private final Map<String, Player> players = new LinkedHashMap<>();
    private int totalScore = 0;

    public Team(String code) {
    	this.code = code;
    }
    
    public String getCode() {
    	return code;
    }
    
    public Map<String, Player> getPlayers() {
    	return players;
    }
    
    public int getTotalScore() {
    	return totalScore;
    }
    
    public void addToScore(int delta) {
    	totalScore += delta;
    }
}
